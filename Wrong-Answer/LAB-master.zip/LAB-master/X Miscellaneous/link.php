Xampp
Download : https://www.apachefriends.org/download.html
https://www.youtube.com/watch?v=I1dfCVDoxCo

Install :      
http://ubuntuportal.com/2013/12/how-to-install-xampp-1-8-3-for-linux-in-ubuntu-desktop.html
https://www.youtube.com/watch?v=IHXcFhEAfPI


Another Way : http://howtoubuntu.org/how-to-install-lamp-on-ubuntu


Code :

root@rashed-H81M-S2PV:/home/rashed/Downloads#      sudo chmod +x xampp-linux-x64-7.1.1-0-installer.run
root@rashed-H81M-S2PV:/home/rashed/Downloads#     ./xampp-linux-x64-7.1.1-0-installer.run

//Full permission Htdocs : sudo chmod -R 755 /opt/lampp/htdocs
In the linux terminal navigate to your lampp directory.
cd /opt/lampp
In the command line type:
sudo chmod 777 -R htdocs

Run obligatory : sudo /opt/lampp/manager-linux-x64.run
Plugin problem : https://www.youtube.com/watch?v=1Grt6NK7goQ

if apace server can not work:
Try using this :

sudo /etc/init.d/apache2 stop
then try starting your xampp

sudo /opt/lampp/lampp start

Uninstall 
1) Open Terminal

2) Go to the lampp folder, like cd /opt/lampp

3) Run command sudo /opt/lampp/uninstall

A popup of xampp will jump asking whether you are sure about this uninstallation.

Click yes

 sudo chmod +x /opt/lampp/uninstall
 sudo /opt/lampp/uninstall

TADAA.. It's done.
or : sudo rm -r /opt/lampp



Install Sublime Text :
Install via the Package Manager(apt-get):

Simply add to your packages:

For Sublime-Text-2:

sudo add-apt-repository ppa:webupd8team/sublime-text-2
sudo apt-get update
sudo apt-get install sublime-text

links: http://askubuntu.com/questions/172698/how-do-i-install-sublime-text-2-3



Uninstall : 
sudo apt-get remove sublime-text-installer
sudo apt-get remove sublime-text

But to remove it completely you will need to call:

sudo apt-get purge --auto-remove sublime-text-installer  
or
sudo apt-get remove --auto-remove sublime-text-installer


Wordpress install
   https://www.youtube.com/watch?v=o2dgPrGrfyM
   https://www.youtube.com/watch?v=o2dgPrGrfyM
   http://linuxg.net/how-to-install-sublime-text-3-build-3083-on-ubuntu-15-04-ubuntu-14-10-ubuntu-14-04-ubuntu-12-04-and-derivatives/
   https://www.youtube.com/watch?v=S2GtxB1N0hI
   
ubuntu write disk : https://www.ubuntu.com/download/desktop/create-a-usb-stick-on-ubuntu


$ sudo add-apt-repository ppa:webupd8team/sublime-text-3

$ sudo apt-get update

$ sudo apt-get install sublime-text-installer

Optional, to remove sublime text, do:

$ sudo apt-get remove sublime-text-installer


Kali linux : virtual box :  
http://www.thegeeky.space/2014/08/details-steps-by-steps-how-to-install-kali-linux-in-ubuntu-virtualbox-for-penetration-testing-and-hacking.html




install
http://sourcedigit.com/18076-how-to-install-tor-browser-bundle-on-ubuntu/
http://idroot.net/linux/install-tor-browser-ubuntu-16-04/





namechaep op up : https://www.youtube.com/watch?v=_ytecpymCN4

Best : https://www.youtube.com/channel/UCb7dMXcNObadaBIM6l45CGQ


https://www.youtube.com/watch?v=WK1rbg4FenQ

https://www.youtube.com/watch?v=FccjPuQeYxs



