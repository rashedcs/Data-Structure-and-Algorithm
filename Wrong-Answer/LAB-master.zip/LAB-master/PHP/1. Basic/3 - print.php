<?php

$txt1 = "Learn PHP";
$txt2 = "W3Schools.com";
$x = 5;
$y = 4;

echo "Study PHP at ". $txt2. "\n";
echo $x + $y. "\n";
echo $x + $y;
?>
