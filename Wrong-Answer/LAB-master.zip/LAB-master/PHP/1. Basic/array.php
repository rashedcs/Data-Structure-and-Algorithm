<?php    
$salary=array("Sonoo"=>"550000","Vimal"=>"250000","Ratan"=>"200000");  
foreach($salary as $k => $v) {  
echo $k. "Value: ".$v."\n";  
}  
?>    
