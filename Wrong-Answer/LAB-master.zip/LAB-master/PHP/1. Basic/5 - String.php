Get The Length of a String
The PHP strlen() function returns the length of a string.

The example below returns the length of the string "Hello world!":

<?php
echo strlen("Hello world!"); // outputs 12
?>
