<?php
$hello = "This is a string";
$a_number = 4;
$anotherNumber = 8;
echo $hello ."<br/>";
$total = $a_number+$anotherNumber;
echo $total;
?>
