http://knowfewprograms.blogspot.com/2015/03/shift-reduce-parser-to-write-c-program.html

http://3rdyearcselabprograms.blogspot.com/2010/01/shift-reduce-parser_15.html
