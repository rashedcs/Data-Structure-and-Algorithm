<?php include 'topber.php'; ?>
<?php include 'sideber.php'; ?>
<?php include 'database.php'; ?>


<?php
   $db = new database();

   if(isset($_POST['submit']))
   {
       $code = $_POST['code'];
       $title = $_POST['title'];

       $query = " SELECT * from subject WHERE code='$code' ";
       $result = $db->select($query);

       if($result!=false)
       {
              $emailError = "Subject is taken";
              echo $emailError;
       }
       else
       {
           $query="INSERT INTO subject(code, title) 
           VALUES('$code', '$title')";
           $result = $db->insert($query);
       }      

  }
?>


<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>

<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}

input[type=text]
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}

.container 
{
    padding-top: 10px;
    padding-right: 100px;
    padding-bottom: 100px;
    padding-left: 100px;
}

</style>


</head>

<body>
  <h2>Add new Student</h2>
  <form action="subject.php" method="POST">
    <div class="container" >

      <label><b>Subject Code</b></label>
      <input type="text"   placeholder="Subject Code" required="1" name="code" />

      <label><b>Subject Title</b></label>
      <input type="text"   placeholder="Subject Title" required="1" name="title" />

     <div>
       <button name="submit" type="submit">Submit</button>
    </div>
  <div>
</form>
</body>
</html>












  

