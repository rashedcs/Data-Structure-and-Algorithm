<?php include 'topber.php'; ?>
<?php include 'sideber.php'; ?>

<?php include 'database.php'; ?>


<?php
   $db = new database();

   if(isset($_POST['submit']))
   {

       $roll  = $_POST['roll'];
       $atten = $_POST['atten_mark'];


 
       $query = "select * from attendence where roll='$roll' ";
       $result = $db->select($query);


       if($result!=false)
       {
           $user_data = mysqli_fetch_array($result);
           $count_row =  mysqli_num_rows($result);

           if( $count_row==1)
           {
              $emailError = "Roll is taken";
              echo $emailError;
           }
       }
       else
       {
           $query="INSERT INTO attendence(roll, atten_mark) 
           VALUES('$roll', '$atten') ";
           $result = $db->insert($query);
       }      

  }
?>




<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>
<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}

input[type=text] 
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}

.container 
{
    padding-top: 10px;
    padding-right: 100px;
    padding-bottom: 100px;
    padding-left: 100px;
}

</style>
</head>

<body>
  <h2>Add Attendence Mark</h2>
  <form action="attend.php" method="POST">
    <div class="container" >

      <label><b>Roll</b></label>
        <select name="roll" class="form-control" id="default" required="required">
          <option value="">Select Roll</option>
          <?php
            $sql= "select roll from student ";
            $result = $db->select($sql);
            while ($row = $result->fetch_assoc()) 
            {
              echo '<option value=" '.$row['roll'].' "> '.$row['roll'].' </option>';
            }
          ?>
        </select>

      <label><b>Attendence Mark</b></label>
       <input type="text"   placeholder="Attendence" required="1" name="atten_mark" />



      <div>
        <button name="submit" type="submit">Submit</button>
      </div>
    </div>
</form>

</body>
</html>







  

