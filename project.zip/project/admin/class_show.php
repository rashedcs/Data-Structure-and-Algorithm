<?php  include 'topber.php';  ?>
<?php  include 'sideber.php'; ?>
<?php  include 'database.php'; ?>


<?php 
     $db = new database();

  
     if (isset($_POST['submit'])) 
     {
          $session    = $_POST['session'];
          $department = $_POST['dept'];

          $query="SELECT distinct student.roll, student.name, student.dept, 
           student.session, 
          attendence.atten_mark
          from student 
          inner join class_assesment on student.roll=class_assesment.roll 
          inner join attendence on student.roll=attendence.roll 
          where dept='$department' and session='$session' order by roll, type";

          $result = $db->select($query);

          if(mysqli_num_rows($result)==0)
          {
              $emailError = "Not available";
              echo $emailError;
          }
          else
          {
                $query="SELECT  roll, type, num, mark from class_assesment 
                order by roll, type, num";
                $resu=$db->select($query);
                $data = Array();

                $roll='150101';

                $acount=0; $ccount=0;
                $i=0; 
                while($raw=mysqli_fetch_assoc($resu)) 
                {
                    $data[$i] = $raw['mark'];
                    $i++;
                    if($roll==$raw['roll']) 
                    {
                       if($raw['type']=='ct') $ccount++;
                       else                   $acount++;
                    }
                }
                $max=$acount+$ccount; 



               echo "<pre><font color=red>Department : $department  Session : $session </font></pre>";

               echo "<table class='table table-bordered'> "; 
                 echo "<thead>";
                  echo "<tr>";
                  echo "<th> Roll </th>";
                  echo "<th> Name </th>";
                  echo "<th> Attendence Mark</th>";

                  for($i=1; $i<=$acount ; $i++) 
                  { 
                    echo '<th id="p">AS-'.$i.'</th>';
                  }

                  for ($i=1; $i<=$ccount ; $i++) 
                  { 
                    echo '<th id="p">CT-'.$i.'</th>';
                  }
                  echo "<th> Best Two </th>";
                  echo "<th> total</th>";
                  echo "<th> Action </th>";
                echo "</tr>"; 
 

              
               $p=0; $l=0; $u=$max;
               while($row=mysqli_fetch_assoc($result)) 
               {

                  echo "<tr>";
                   echo "<td> $row[roll]</td>";
                   echo "<td> $row[name]</td>";
                   echo "<td> $row[atten_mark]</td>";

                  $t=0;
                   $best = [];
                   for($i=$l; $i<$u; $i++) 
                   { 
                      $best[$t]=$data[$i];
                      echo '<td>'.$data[$i].'</td>';
                      $t++;
                   }
				   $l=$u;
				   $u=$u+$max;
	

                    
                   $url="edit.php?roll=".$row['roll'];

                   rsort($best);
                   echo '<td>'.($best[0]+$best[1]).'</td>';
                   echo '<td>'.($best[0]+$best[1]+$row['atten_mark']).'</td>';
				   echo '<td><a id="edit" href="'.$url.'"target="_blank">Edit</a></td></tr>';
				   
				   
                  echo "</tr>"; 
               }
               
             echo "</table>" ; 
             exit(); 

      }
    }
?>




<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>

<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}

input[type=text], input[type=password] 
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}

.container 
{
    /*
    padding: 10px 100px 100px 100px;   
    */
    padding-top: 10px;
    padding-right: 100px;
    padding-bottom: 100px;
    padding-left: 100px;
}

</style>


</head>

<body>
  <h2>Add new Student</h2>
  <form action="" method="POST">
    <div class="container" >
      <label><br>Depertment </br></label>
        <select name="dept" class="form-control" id="default" required="required">
          <option value="">Select Class</option>
          <option value="CSE">CSE</option>
          <option value="EEE">EEE</option>
          <option value="ICE">ICE</option>
          <option value="ETE">ETE</option>
        </select>
    
       <label><br>Session</br></label>
          <select name="session" class="form-control" id="default" required="required">
          <option value="">Select Session</option>
          <option value="2011-12">2011-12</option>
          <option value="2012-13">2012-13</option>
          <option value="2013-14">2013-14</option>
          <option value="2014-15">2014-15</option>
          <option value="Other">Other</option>
        </select>

     <div>
       <button name="submit" type="submit">Submit</button>
    </div>
  <div>
</form>
</body>
</html>
