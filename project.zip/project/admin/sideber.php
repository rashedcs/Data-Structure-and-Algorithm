<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="dashboard.php"><i class="fa fa-fw fa-dashboard">
                        </i> Dashboard</a>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo">
                        <i class="fa fa-fw fa-arrows-v"></i> Student <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="registration.php">Add Student</a>
                            </li>
                            <li>
                                <a href="edit.php">Manage Student</a>
                            </li>
                        </ul>
                    </li>

                     <li>
                        <a href="about.php"><i class="fa fa-fw fa-desktop"></i>Admission</a>
                    </li>


                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#hemo">
                        <i class="fa fa-fw fa-desktop"></i> Subject<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="hemo" class="collapse">
                            <li>
                                <a href="subject.php">Add Subject</a>
                            </li>
                        </ul>
                    </li>
                   <li>

                    
                    <li>
                        <a href="research.php"><i class="fa fa-fw fa-desktop"></i>Research</a>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#remo">
                        <i class="fa fa-fw fa-arrows-v"></i> Result <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="remo" class="collapse">
                            <li>
                                <a href="add.php">Add Result</a>
                            </li>
                            <li>
                                <a href="show.php">Manage Result</a>
                            </li>
                        </ul>
                    </li>

                     <li>
                        <a href="routin.php"><i class="fa fa-fw fa-wrench"></i>Routine</a>
                    </li>

       
                </ul>
            </div>
        </nav>

        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
              <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dashboard <small>Statistics Overview</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
