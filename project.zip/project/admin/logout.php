<?php
 session_start();
 if(!isset($_SESSION['id'])) 
 {
  header("Location: ../login.php");
 } 

 else if(isset($_SESSION['user'])!="") 
 {
   header("Location: ../index.php");
 }
 
 if (isset($_GET['logout'])) 
 {
  unset($_SESSION['id']);
  session_unset();
  session_destroy();
  header("Location: ../login.php");
  exit;
 }
 ?>