<?php include 'topber.php'; ?>
<?php include 'sideber.php'; ?>



<?php
   include 'database.php'; 
   $db = new database();
   if(isset($_POST['submit']))
   {
          $roll = $_POST['roll'];
          $mark = $_POST['mark'];
          $code = $_POST['code'];

          $count = count($mark);


          $query="SELECT * FROM result where roll='$roll' ";
          $result = $db->select($query);

          if($result!=false)
          {
              $Error = "Roll is taken";
              echo $Error;
          }
  
          else
          {
               for($i=0; $i<$count; $i++)
                {

                    $ro = $roll;
                    $ma = $mark[$i];
                    $co = $code[$i];
                    $sql = " insert into result(roll, code, mark) 
                           values('$ro', '$co', '$ma') ";
                    $db->insert($sql);
                }
         }
      }
?>


<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>
<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}

input[type=text] 
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}

.container 
{
    padding-top: 10px;
    padding-right: 100px;
    padding-bottom: 100px;
    padding-left: 100px;
}

</style>
</head>

<body>
  <h2>Add Class Test Marks</h2>
  <form action="add.php" method="POST">
    <div class="container" >
      <label><b>Roll</b></label>
        <select name="roll" class="form-control" id="default" required="required">
         <option value="">Select Roll</option>
         <?php
           $sql= "select roll from student  ";
           $result = $db->select($sql);
           while ($row = $result->fetch_assoc()) 
           {
             echo '<option value=" '.$row['roll'].' "> '.$row['roll'].' </option>';
           }
        ?>
      </select>

     <br>Subject<br />
      <?php
          $sql= "select code from subject  ";
          $res = $db->select($sql);
 
          while($raw = $res->fetch_assoc()) 
          {
            echo '<label><br>'.$raw['code'].'</br></label>';
            echo '<input type="hidden" name="code[]" value="'. $raw['code']. '">';
            echo '<input type="text" placeholder="mark" required="1" name="mark[]"/>';
          }
       ?>

      <div>
        <button name="submit" type="submit">Submit</button>
      </div>
   <div>
</form>

</body>
</html>






