<?php  include 'topber.php';  ?>
<?php  include 'sideber.php'; ?>
<?php  include 'database.php'; ?>


<?php 
     $db = new database();


          $query="SELECT distinct student.roll, student.name, student.dept, 
           student.session
          from student 
          inner join result on student.roll=result.roll  
          where dept='CSE' and session='2014-15' order by roll, code";

          $result = $db->select($query);

          if(mysqli_num_rows($result)==0)
          {
              $emailError = "Not available";
              echo $emailError;
          }
          else
          {
                $query="SELECT code, mark from result ";
                $resu=$db->select($query);

                $code = Array();
                $mark = Array();
               
                $i=0;
                while($raw=mysqli_fetch_assoc($resu)) 
                {
                    $mark[$i] = $raw['mark'];
                    $code[$i] = $raw['code'];
                    $i++;
                }
                
                $max=2; 

               echo "<table class='table table-bordered'> "; 
                 echo "<thead>";
                  echo "<tr>";
                  echo "<th> Roll </th>";
                  echo "<th> Name </th>";
                  for($i=0; $i<2; $i++) 
                  { 
                     echo '<th>'.$code[$i].'</th>';
                  }
                  echo "<th> Action </th>";
                echo "</tr>"; 
 

                $l=0; $u=$max;
               while($row=mysqli_fetch_assoc($result)) 
               {
                  echo "<tr>";
                   echo "<td> $row[roll]</td>";
                   echo "<td> $row[name]</td>";

                   for($i=$l; $i<$u; $i++) 
                   { 
                      echo '<td> '.$mark[$i].' </td>';
                   }
                   $l=$u;
                   $u=$u+$max;

                    
                   $url="edit.php?roll=".$row['roll'];

              echo '<td><a id="edit" href="'.$url.'"target="_blank">Edit</a></td></tr>';
             
                   echo "</tr>"; 
               }
               
             echo "</table>" ; 
            
             exit(); 

          }
    
?>


