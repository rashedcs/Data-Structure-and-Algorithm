<?php include 'topber.php'; ?>
<?php include 'sideber.php'; ?>



<?php
   include 'database.php'; 
   $db = new database();
   if(isset($_POST['submit']))
   {
          $roll = $_POST['roll'];
          $type = $_POST['ca'];
          $mark = $_POST['mark'];


        /** Count the number according to query **/
          $query="SELECT * FROM class_assesment where roll='$roll'";
          $cat = $db->select($query);
          $i=0;
          if($cat)
          {
              while($result=$cat->fetch_assoc())
              {
                  $i++;
              }
          }
          $i=$i+1;


          $query="INSERT INTO  class_assesment(roll, type, num, mark) 
          VALUES('$roll','$type', '$i','$mark') ";
          $result = $db->insert($query);
          echo "<script>location.href='class.php';</script>";         
         //header("Location : class.php");
}
?>


<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>
<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}

input[type=text] 
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}

.container 
{
    padding-top: 10px;
    padding-right: 100px;
    padding-bottom: 100px;
    padding-left: 100px;
}

</style>
</head>

<body>
  <h2>Add Class Test Marks</h2>
  <form action="class.php" method="POST">
    <div class="container" >
      <label><b>Roll</b></label>
        <select name="roll" class="form-control" id="default" required="required">
        <option value="">Select Roll</option>
        <?php
          $sql= "select roll from student ";
          $result = $db->select($sql);
          while ($row = $result->fetch_assoc()) 
          {
            echo '<option value=" '.$row['roll'].' "> '.$row['roll'].' </option>';
          }
        ?>
      </select>

      <label><br>Class Assesment </br></label>
        <select name="ca" class="form-control" id="default" required="required">
          <option value="">Select Type</option>
          <option value="ct">Class Test</option>
          <option value="am">Assignment</option>
        </select>

      <label><b>Marks</b></label>
      <input type="text"   placeholder="Marks" required="1" name="mark" />

      <div>
        <button name="submit" type="submit">Submit</button>
      </div>
   <div>
</form>

</body>
</html>







  

