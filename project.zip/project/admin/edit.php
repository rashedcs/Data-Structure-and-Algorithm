<?php include 'topber.php'; ?>
<?php include 'sideber.php'; ?>
<?php include 'database.php'; ?>


<?php
$db = new database();
if($_GET)
{
   $roll = $_GET['roll']; 
   echo $roll;
   $query = "select * from result where roll='$roll' ";
   $res = 	$db->select($query);	
   $arr = Array();
}
?>



<?php
   include 'database.php'; 
   $db = new database();
   if(isset($_POST['submit']))
   {
            $id =   $roll;
            $mark = $_POST['mark'];
            $code = $_POST['code'];

            $count = count($mark);

            for($i=0; $i<$count; $i++)
            {
                $roll = $id;
                $ma = $mark[$i];
                $co = $code[$i];
                $sql = " insert into result(roll, code, mark) 
                       values('$ro', '$co', '$ma') ";
                $db->insert($sql);
            }
    }
      
?>
	


<!DOCTYPE html>
<head>
<meta charset="utf-8">
<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}

input[type=text] 
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}

.container 
{
    padding-top: 10px;
    padding-right: 100px;
    padding-bottom: 100px;
    padding-left: 100px;
}

</style>
</head>

<body>
  <h2>Add Class Test Marks</h2>
  <form action="edit.php" method="POST">
    <div class="container" >
	  <?php
          while($row = $res->fetch_assoc()) 
          {
		        echo '<label><b>'.$row['code'].'</b></label>';
            echo '<input type="text" value='.$row['mark'].' required="1" name="mark[]"/>';
            
          }
	  ?>


      <div>
        <button name="submit" type="submit">Submit</button>
      </div>
   <div>
</form>

</body>
</html>
