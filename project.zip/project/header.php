<!DOCTYPE html>
<html lang="en">
<head>
  <title>Website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/bootstrap.min.js"></script>
  
  <style>
  .container 
   {
       padding: 10px 150px 150px 250px;
   }


  </style>
</head>

<body>
<div class="container">                 
  <ul class="nav nav-pills" >
    <li class="active"><a href="index.php">Home</a></li>
    <li><a href="login.php">Login</a> </li>
    <li><a href="about.php">About Us</a> </li>
    <li><a href="contact.php">Contact Us</a> </li>
  </ul>
</div>

</body>
</html>
