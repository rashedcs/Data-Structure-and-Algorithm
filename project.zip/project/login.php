<?php include 'header.php'; ?>

<?php 
session_start();
include 'database.php'; 
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Sign In</title>
<style>
form 
{
    border: 3px solid #f1f1f1;
}
h2
{
    text-align: center;
    color: green;
}
input[type=text], input[type=password] 
{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button 
{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover 
{
    opacity: 0.8;
    background-color: red;
}



</style>
</head>



<?php 
$db = new database();

 if($_SERVER['REQUEST_METHOD']=='POST')
 { 
      
      $username = trim($_POST['username']);
      $username = strip_tags($username);
      $username = htmlspecialchars($username);
      
        
      $password = trim($_POST['password']);
      $password = strip_tags($password);
      $password = htmlspecialchars($password);
    

      // $password = md5($password);

     // $password = hash('sha256', $password);

      $query = "SELECT * from admin WHERE username='$username' and password='$password' ";
      
      $result = $db->select($query);
      
      if($result!=false)
      {
           $user_data = mysqli_fetch_array($result);
           $count_row = mysqli_num_rows($result);

           if($count_row==1) 
           {
              $_SESSION['login'] = true; // this login var will use for the session thing
              $_SESSION['id'] = $user_data['userid'];
              $_SESSION['username'] = $user_data['username'];
              header("location: admin/dashboard.php");
           }
           else 
           {
              echo "Wrong username or password";
           }
       }
    }
?>

<body>
<h2>Login</h2>
<form action=""  method="POST">
  <div class="container">
    <label><b>Username</b></label>
    <input type="text" placeholder="Username" required="1" name="username" />

    <label><b>Password</b></label>
    <input type="password" placeholder="Password" required="1" name="password"/>
        
    <button type="submit">Login</button>
  </div>
</form
<?php include 'footer.php'; ?>

</body>
</html>




