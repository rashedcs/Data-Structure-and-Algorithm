create table if not exists admin
(
  userid int auto_increment,
  username varchar(25),
  password varchar(25),
  primary key(userid)
);


create table if not exists subject
(
  id int auto_increment,
  code varchar(55) not null,
  title varchar(55) not null,
  primary key(id)
);



create table if not exists student
(
  id int auto_increment,
  roll int(6) not null,
  name varchar(55) not null,
  dept varchar(55) not null,
  session varchar(55) not null,
  primary key(id, roll)
);


create table if not exists subject
(
  id int auto_increment,
  code varchar(55) not null,
  title varchar(55) not null,
  primary key(id)
);



create table if not exists result
(
  id int auto_increment,
  roll int(6) not null,
  code varchar(55) not null,
  title varchar(55) not null,
  mark int;
  primary key(id)
);




create table if not exists attendence
(
   id int  auto_increment,
   roll  int(6) not null,
   atten_mark int not null,
   primary key(id, roll)
);




create table if not exists class_assesment
(
  id int auto_increment,
  roll int(6) not null,
  type varchar(20) not null,
  num  int    not null,
  mark int(2) not null,
  primary key(id, roll)
);

