<html>

<style>
.footer 
{
    background-color: #f1f1f1;
    padding : 10px;
    text-align: center;
}

</style>


<div class="footer">
   <p>Site Designed by Hablu Inc</p>
</div>
</body
</html>